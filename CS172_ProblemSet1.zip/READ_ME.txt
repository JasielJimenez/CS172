To compile the code, use:
python3 problemSet1.py

It doesn�t separate links into separate words, but may have some problems with �/�

*The data (files 1 - 20) and the stop words list must be in the same folder as problemSet1.py for it to work
