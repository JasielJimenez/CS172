#Libraries-------------------------------------------------------------------------------------------------------------------------------

import math

#ListofDocuments-------------------------------------------------------------------------------------------------------------------------------

documentList = ["file01.txt", "file02.txt", "file03.txt", "file04.txt", "file05.txt", "file06.txt", "file07.txt", "file08.txt", "file09.txt", "file10.txt", "file11.txt", "file12.txt", "file13.txt", "file14.txt", "file15.txt", "file16.txt", "file17.txt", "file18.txt", "file19.txt", "file20.txt"]

#Classes-------------------------------------------------------------------------------------------------------------------------------

class Posting:
    def __init__(self):
        self.documentID = -1
        self.docFrequency = 1

class Term:
    def __init__(self):
        self.numberofDocuments = 1
        self.term = ""
        self.posts = dict()
    def change(self, documentID):
        exists = self.posts.get(documentID)
        if (exists == None):
            exists = Posting()
            exists.documentID = documentID 
            self.posts[documentID] = exists
        else:
            exists.docFrequency = exists.docFrequency + 1


class DocumentIndex:
    def __init__(self):
        self.hashTable = dict()
        self.invertedDocumentIndex = dict()
    def change(self, documentID, termName):
        exists = self.hashTable.get(termName)
        if (exists == None):
            exists = Term()
            exists.term = termName
            exists.change(documentID)
            self.hashTable[termName] = exists
        else:
            exists.change(documentID)

    def printPosts(self, termName):
        exists = self.hashTable.get(termName)
        if (exists == None):
            print("%s either could not be found or is a stopword" % termName)
        else:
            documentCollection = len(self.invertedDocumentIndex)
            IDF = math.log10(float(documentCollection) / exists.numberofDocuments)
            allDocs = list(exists.posts.values())
            numDocuments = 0;
            for i in range(len(allDocs)):
                current = allDocs[i]
                print("DocumentID = %d" % (current.documentID), end='')
                TF = float(current.docFrequency) / self.invertedDocumentIndex.get(current.documentID).docFrequency
                TFIDF = TF * IDF
                print(", TF = (%f)" % (TF), end='')
                print(", IDF = (%f)" % (IDF), end='')
                print(", TF-IDF = (%f)" % (TFIDF))
                numDocuments = numDocuments + 1;
                
            print(" # of documents the term shows up in: %i" % numDocuments)

#Main-------------------------------------------------------------------------------------------------------------------------------

if __name__ == "__main__":
    documentIndex = DocumentIndex()
    stopList = dict()
    readInput = open("stoplist.txt")
    documentInput = readInput.readline()
    while documentInput != "":
        documentInput = documentInput.replace('\n', '')
        documentInput = documentInput.replace('\r', '')
        documentInput = documentInput.split(" ")
        for i in range(len(documentInput)):
            currentInput = documentInput[i]
            if currentInput == "":
                continue
            stopList[currentInput] = currentInput
        documentInput = readInput.readline()
    
    readInput.close()
    documentID = 1
    for i in range(len(documentList)):
        invertedDocumentIndex = Posting()
        invertedDocumentIndex.documentID = documentID
        invertedDocumentIndex.docFrequency = 0
        documentName = documentList[i]
        readInput = open(documentName)
        documentInput = readInput.readline()
        while documentInput != "":
            documentInput = documentInput.replace('\n', '')
            documentInput = documentInput.replace('\r', '')
            documentInput = documentInput.replace('-', ' ')
            documentInput = documentInput.split(" ")
            for j in range(len(documentInput)):
                inStopList = stopList.get(documentInput[j].lower())
                if (inStopList == None):
                    documentIndex.change(documentID, documentInput[j].lower())
                    invertedDocumentIndex.docFrequency = invertedDocumentIndex.docFrequency + 1
            documentInput = readInput.readline()
        documentIndex.invertedDocumentIndex[documentID] = invertedDocumentIndex
        #print(invertedDocumentIndex.docFrequency)
        documentID = documentID + 1

 #TEST---------------------------------------------------------------------------------------------  
    continueInput = True

    while(continueInput):
 
        takeInput = input("Input: ")
        
        if (takeInput == "QUIT"):
            continueInput = False
            continue
        else:
            documentIndex.printPosts(takeInput.lower())
  #-------------------------------------------------------------------------------------------------